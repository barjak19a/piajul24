export class User {
    username: string = "";
    password: string = "";
    firstName: string = "";
    lastName: string = "";
    gender: string = "";
    address: string = "";
    phoneNumber: string = "";
    email: string = "";
    profilePicture: string = "";
    creditCard: string = "";
    role: string = "guest";
    status: string = "";
    restaurantName: string = "";
}
